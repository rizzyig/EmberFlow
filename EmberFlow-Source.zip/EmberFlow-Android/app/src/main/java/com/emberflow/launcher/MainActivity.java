package com.emberflow.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private LinearLayout root, content, clockBox, clockRow, appGrid;
    private TextView clockText, dateText, statusText;
    private EditText searchField;
    private boolean isPro() { return BuildConfig.FLAVOR.equals("pro"); }
    private boolean isLite() { return BuildConfig.FLAVOR.equals("lite"); }
    private boolean settingsOpen = false;
    private final List<AppEntry> apps = new ArrayList<>();
    private int selectedIndex = 0;

    private static final String[] PREF_KEYS = {"clockStyle","clockSize","clockPosition","frost","shine","panelBlur","showDate","hour24","showLabels"};
    private static final String[] DEFAULTS = {"glass","1","1","4","65","12","true","false","true"};

    private Runnable clockTick = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("emberflow_settings", MODE_PRIVATE);
        buildHome();
        handler.post(clockTick);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(clockTick);
        super.onDestroy();
    }

    private int prefInt(String key) {
        try { return Integer.parseInt(prefs.getString(key, defaultFor(key))); }
        catch (Exception e) { return 0; }
    }
    private String defaultFor(String key) {
        for (int i=0;i<PREF_KEYS.length;i++) if (PREF_KEYS[i].equals(key)) return DEFAULTS[i];
        return "0";
    }
    private String prefString(String key) { return prefs.getString(key, defaultFor(key)); }
    private boolean prefBool(String key) { return prefs.getBoolean(key, Boolean.parseBoolean(defaultFor(key))); }
    private void setString(String key, String value) { prefs.edit().putString(key, value).apply(); }
    private void setBool(String key, boolean value) { prefs.edit().putBoolean(key, value).apply(); }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (strokeColor != 0) d.setStroke(2, strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(12); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(bg(Color.rgb(27,48,77), 20, Color.rgb(62,91,124)));
        b.setPadding(12, 4, 12, 4);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void buildHome() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 18, 24, 16);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(4,68,177), Color.rgb(8,123,222), Color.rgb(2,12,40)}));

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        clockText = text("", 52, Color.WHITE);
        clockText.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        dateText = text("", 13, Color.rgb(224,243,255));
        titleCol.addView(clockText);
        dateText.setPadding(2, 6, 0, 0);
        titleCol.addView(dateText);
        header.addView(titleCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (!isLite()) header.addView(button("⚙ Settings", this::showSettings));
        else header.addView(button("Apps", () -> { if (appGrid != null && appGrid.getChildCount() > 0) appGrid.getChildAt(0).requestFocus(); }));
        root.addView(header, new LinearLayout.LayoutParams(-1, 0, 2));

        TextView allApps = text("All apps", 17, Color.WHITE);
        allApps.setTypeface(null, Typeface.BOLD);
        allApps.setPadding(0, 10, 0, 12);
        root.addView(allApps);
        if (isPro()) {
            searchField = new EditText(this);
            searchField.setSingleLine(true);
            searchField.setTextColor(Color.WHITE);
            searchField.setHintTextColor(Color.rgb(190,215,240));
            searchField.setHint("Search apps · long-press an app to favourite it");
            searchField.setTextSize(14);
            searchField.setPadding(16, 6, 16, 6);
            searchField.setBackground(bg(Color.argb(45,255,255,255), 18, Color.argb(100,255,255,255)));
            root.addView(searchField, new LinearLayout.LayoutParams(-1, 48));
            searchField.addTextChangedListener(new android.text.TextWatcher() {
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                public void onTextChanged(CharSequence s, int start, int before, int count) { renderApps(); }
                public void afterTextChanged(android.text.Editable e) {}
            });
        }
        ScrollView scroll = new ScrollView(this);
        appGrid = new LinearLayout(this);
        appGrid.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(appGrid);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 5));
        statusText = text(isPro() ? "EmberFlow Pro · Long-press apps to favourite" : isLite() ? "EmberFlow Lite · Lightweight home" : "EmberFlow · Settings saved on this device", 11, Color.rgb(204,229,255));
        statusText.setPadding(0, 10, 0, 0);
        root.addView(statusText);
        setContentView(root);
        loadApps();
        renderApps();
        applyClockSettings();
    }

    private void updateClock() {
        if (clockText == null) return;
        String pattern = prefBool("hour24") ? "HH:mm" : "h:mm";
        clockText.setText(new SimpleDateFormat(pattern, Locale.getDefault()).format(new Date()));
        dateText.setText(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()).toUpperCase(Locale.getDefault()));
        dateText.setVisibility(prefBool("showDate") ? View.VISIBLE : View.GONE);
    }

    private void applyClockSettings() {
        if (clockText == null) return;
        int size = prefInt("clockSize");
        clockText.setTextSize(size == 0 ? 34 : size == 2 ? 66 : 52);
        int pos = prefInt("clockPosition");
        ((LinearLayout)clockText.getParent()).setGravity(pos == 0 ? Gravity.LEFT : pos == 2 ? Gravity.RIGHT : Gravity.CENTER_HORIZONTAL);
        String style = prefString("clockStyle");
        int frost = prefInt("frost"), shine = prefInt("shine"), blur = prefInt("panelBlur");
        int base = style.equals("solid") ? Color.WHITE : Color.argb(Math.min(255, 180 + shine/2), 239, 249, 255);
        clockText.setTextColor(base);
        clockText.setShadowLayer(style.equals("neon") ? 14 : Math.max(0, frost), 0, 2, style.equals("neon") ? Color.rgb(87,222,255) : Color.argb(Math.min(200, 30+frost*12), 220,245,255));
        if (style.equals("glass")) {
            clockText.setBackground(bg(Color.argb(Math.min(95, 18+blur*2), 220,242,255), 24,
                    Color.argb(Math.min(230, 60+frost*15), 255,255,255)));
            clockText.setPadding(18, 8, 18, 8);
        } else {
            clockText.setBackgroundColor(Color.TRANSPARENT);
            clockText.setPadding(0, 8, 0, 8);
        }
        updateClock();
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(query, 0);
        for (android.content.pm.ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            apps.add(new AppEntry(ri.loadLabel(pm).toString(), pkg, ri.activityInfo.name, ri.loadIcon(pm)));
        }
        apps.sort((a,b) -> a.label.compareToIgnoreCase(b.label));
    }

    private void renderApps() {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        List<AppEntry> shown = new ArrayList<>();
        String query = isPro() && searchField != null ? searchField.getText().toString().trim().toLowerCase(Locale.ROOT) : "";
        java.util.Set<String> favourites = prefs.getStringSet("favourites", new java.util.HashSet<>()) ;
        for (AppEntry app : apps) {
            if (query.isEmpty() || app.label.toLowerCase(Locale.ROOT).contains(query)) shown.add(app);
        }
        if (isPro()) shown.sort((a,b) -> {
            boolean af = favourites.contains(a.pkg), bf = favourites.contains(b.pkg);
            if (af != bf) return af ? -1 : 1;
            return a.label.compareToIgnoreCase(b.label);
        });
        int columns = 5;
        LinearLayout row = null;
        for (int i=0; i<shown.size(); i++) {
            if (i % columns == 0) {
                row = horizontal();
                row.setGravity(Gravity.TOP);
                appGrid.addView(row, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            AppEntry app = shown.get(i);
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(5, 10, 5, 10);
            tile.setFocusable(true);
            tile.setClickable(true);
            tile.setBackground(bg(Color.argb(favourites.contains(app.pkg) && isPro() ? 95 : 54, 220,242,255), 22, Color.argb(90,255,255,255)));
            tile.setOnFocusChangeListener((v, focused) -> tile.setBackground(bg(Color.argb(focused ? 125 : 54, 220,242,255), 22, focused ? Color.WHITE : Color.argb(90,255,255,255))));
            android.widget.ImageView icon = new android.widget.ImageView(this);
            icon.setImageDrawable(app.icon);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(48,48);
            tile.addView(icon, ip);
            if (prefBool("showLabels") || isLite()) {
                TextView label = text((isPro() && favourites.contains(app.pkg) ? "★ " : "") + app.label, 11, Color.WHITE);
                label.setGravity(Gravity.CENTER);
                label.setMaxLines(2);
                tile.addView(label);
            }
            tile.setOnClickListener(v -> launch(app));
            tile.setOnLongClickListener(v -> {
                if (!isPro()) return false;
                java.util.Set<String> updated = new java.util.HashSet<>(prefs.getStringSet("favourites", new java.util.HashSet<>()));
                if (!updated.add(app.pkg)) updated.remove(app.pkg);
                prefs.edit().putStringSet("favourites", updated).apply();
                statusText.setText((updated.contains(app.pkg) ? "★ Added favourite: " : "Removed favourite: ") + app.label);
                renderApps();
                return true;
            });
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, 105, 1);
            tp.setMargins(4, 4, 4, 4);
            row.addView(tile, tp);
        }
        if (shown.isEmpty()) {
            TextView empty = text(query.isEmpty() ? "No launchable apps found." : "No apps match your search.", 14, Color.WHITE);
            appGrid.addView(empty);
        }
    }

    private void launch(AppEntry app) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(app.pkg);
            if (i != null) startActivity(i);
            else statusText.setText("Can't open " + app.label);
        } catch (Exception e) { statusText.setText("Unable to launch " + app.label); }
    }

    private void showSettings() {
        settingsOpen = true;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(24, 18, 24, 18);
        panel.setBackgroundColor(Color.rgb(13, 28, 49));
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        TextView heading = text("EmberFlow Settings", 24, Color.WHITE);
        heading.setTypeface(null, Typeface.BOLD);
        body.addView(heading);
        TextView subtitle = text("Changes apply immediately and are saved automatically.", 12, Color.rgb(180,207,235));
        subtitle.setPadding(0, 4, 0, 14);
        body.addView(subtitle);
        addChoice(body, "Clock style", new String[]{"Frosted glass","Minimal","Ice glow","Solid"}, new int[]{0,1,2,3}, prefString("clockStyle").equals("glass")?0:prefString("clockStyle").equals("minimal")?1:prefString("clockStyle").equals("neon")?2:3, value -> {
            setString("clockStyle", new String[]{"glass","minimal","neon","solid"}[value]); applyClockSettings();
        });
        addSlider(body, "Frost intensity", 0, 10, prefInt("frost"), value -> {setString("frost",String.valueOf(value));applyClockSettings();});
        addSlider(body, "Glass highlights", 0, 100, prefInt("shine"), value -> {setString("shine",String.valueOf(value));applyClockSettings();});
        addSlider(body, "Background blur", 0, 24, prefInt("panelBlur"), value -> {setString("panelBlur",String.valueOf(value));applyClockSettings();});
        addChoice(body, "Clock size", new String[]{"Small","Medium","Large"}, new int[]{0,1,2}, prefInt("clockSize"), value -> {setString("clockSize",String.valueOf(value));applyClockSettings();});
        addChoice(body, "Clock position", new String[]{"Left","Centre","Right"}, new int[]{0,1,2}, prefInt("clockPosition"), value -> {setString("clockPosition",String.valueOf(value));applyClockSettings();});
        addToggle(body, "Show date", prefBool("showDate"), value -> {setBool("showDate",value);updateClock();});
        addToggle(body, "24-hour time", prefBool("hour24"), value -> {setBool("hour24",value);updateClock();});
        addToggle(body, "Show app labels", prefBool("showLabels"), value -> {setBool("showLabels",value);renderApps();});
        scroll.addView(body);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        panel.addView(button("← Back to home", () -> { settingsOpen=false; buildHome(); }), new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(panel);
    }

    interface IntAction { void run(int value); }
    interface BoolAction { void run(boolean value); }

    private void addChoice(LinearLayout parent, String label, String[] options, int[] values, int selected, IntAction action) {
        TextView title = text(label, 14, Color.WHITE);
        title.setPadding(0, 13, 0, 6);
        parent.addView(title);
        LinearLayout row = horizontal();
        for (int i=0;i<options.length;i++) {
            final int v=values[i];
            Button b=button(options[i], () -> action.run(v));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            lp.setMargins(2,2,2,2);
            row.addView(b,lp);
        }
        parent.addView(row);
    }

    private void addSlider(LinearLayout parent, String label, int min, int max, int value, IntAction action) {
        TextView title = text(label + " · " + value, 14, Color.WHITE);
        title.setPadding(0, 12, 0, 0);
        parent.addView(title);
        SeekBar seek = new SeekBar(this);
        seek.setMax(max-min); seek.setProgress(value-min);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                title.setText(label + " · " + (p+min));
                action.run(p+min);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        parent.addView(seek);
    }

    private void addToggle(LinearLayout parent, String label, boolean checked, BoolAction action) {
        Button b = button(label + ": " + (checked ? "On" : "Off"), () -> {
            boolean next = !prefBool(label.equals("Show date") ? "showDate" : label.equals("24-hour time") ? "hour24" : "showLabels");
            action.run(next);
            bRefreshHack(parent, label, next);
        });
        b.setText(label + ": " + (checked ? "On" : "Off"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 7, 0, 2);
        parent.addView(b, lp);
    }

    private void bRefreshHack(LinearLayout parent, String label, boolean next) {
        // Persisted setting is the source of truth; button label refresh is intentionally simple.
        for (int i=0;i<parent.getChildCount();i++) {
            View v=parent.getChildAt(i);
            if (v instanceof Button && ((Button)v).getText().toString().startsWith(label+":")) {
                ((Button)v).setText(label+": "+(next?"On":"Off"));
                break;
            }
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && settingsOpen) {
            settingsOpen=false; buildHome(); return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private static class AppEntry {
        String label, pkg, activity;
        android.graphics.drawable.Drawable icon;
        AppEntry(String l,String p,String a,android.graphics.drawable.Drawable i){label=l;pkg=p;activity=a;icon=i;}
    }
}
