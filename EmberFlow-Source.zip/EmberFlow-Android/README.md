# EmberFlow launcher editions

EmberFlow is a lightweight Android/Fire TV home-screen launcher prototype. All three editions are free.

## Editions
- **Lite** (`com.emberflow.launcher.lite`): minimal home screen and app grid.
- **Normal** (`com.emberflow.launcher.normal`): clock styling controls and persistent settings.
- **Pro** (`com.emberflow.launcher.pro`): Normal features plus app search and long-press favourites. Pro is free; it does not require payment.

Each edition has a separate application ID, so you can install them side-by-side while testing. They all register as HOME candidates; choose one as the default only after confirming it works with your Fire TV remote.

## Build APKs in GitHub Actions
1. Upload the contents of this folder to a GitHub repository.
2. Open **Actions** and run **Build EmberFlow Editions** (pushes to `main` or `master` also trigger it).
3. Download the three APK artifacts from the completed workflow run.

The APKs are debug builds intended for testing. This project has not yet been device-tested on a Fire TV Stick; test launching apps, D-pad navigation, Back, sleep/wake, and recovery to Fire OS before disabling the stock launcher.
